import React from "react";
import "../components/Blogfile.css";
import rightimg from "./images/blog-post-img-1.jpg";
import leftcoolimg from "./images/sidebar-img-1.jpg";
import postimge from "./images/blog-post-img-2.jpg";
import blogpostfst from "./images/blog-post-img-1-150x150.jpg";
import blogpostthrd from "./images/blog-post-img-3-150x150.jpg";
import imgpart from "./images/blog-post-img-3.jpg";
import coconutimg from "./images/blog-post-img-4.jpg";
import logofooter from "./images/logo-footer.png";
import galleryimg from "./images/galleyimg1.jpg";
import galleryimgtwo from "./images/galleyimg2.jpg";
import galleryimgthr from "./images/galleyimg3.jpg";
import galleryimgfrth from "./images/galleyimg4.jpg";
import galleryimgfift from "./images/galleyimg5.jpg";
import galleryimgsix from "./images/galleyimg6.jpg";

function Blogfile() {
  return (
    <div>
      <section className="firstsection">
        <div className="backgrd_img">
          <div className="container">
            <div className="row">
              <div className="col-md-10 mx-auto ">
                <div className="first_middle">
                  <h1>Left Sidebar</h1>
                  <h5>
                    Modern &amp; Beautiful WordPress Theme for all Kinds of
                    Travel and Tourism Busines.
                  </h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="secondsec ">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <form>
                <div className="leftinpt">
                  <div class="input-group p-1 inptbox">
                    <input
                      type="text"
                      class="form-control form-control-lg "
                      placeholder="Search..."
                    />
                    <span class="input-group-text serch-icon">
                      <i class="fa-solid fa-magnifying-glass"></i>
                    </span>
                  </div>
                </div>
              </form>

              <div className="mt-5 leftpara">
                <h4>About Author</h4>
                <p className="mt-3">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras
                  sollicitudin, tellus vitae condimentum egestas, libero dolor
                  auctor tellus, eu consectetur neque elit quis nunc.
                </p>
              </div>

              <div className="categories">
                <h4>Categories</h4>
                <ul>
                  <li>
                    <a href="">Exploring(3)</a>
                  </li>
                  <li className="pt-3">
                    <a href="">Holidays(8)</a>
                  </li>
                  <li className="pt-3">
                    <a href="">Travels(16)</a>
                  </li>
                  <li className="pt-3">
                    <a href="">Videos(2)</a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-8 col-sm-12">
              <div className="rightimg">
                <img src={rightimg}></img>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-4">
              <div className="leftimg ">
                <a href="">
                  <img src={leftcoolimg}></img>
                </a>
              </div>

              <div className="lest-post mt-5">
                <h2>Latest Posts</h2>
                <div className=" mt-4">
                  <div className="d-flex">
                    <div className="smallfirst">
                      <a href="">
                        <img src={blogpostfst}></img>
                      </a>
                    </div>
                    <div className="ml-3 smllfstpara">
                      <h5>Exotic beaches</h5>
                      <p>
                        <a href="">August 7, 2017</a>
                      </p>
                    </div>
                  </div>

                  <div className="d-flex mt-2">
                    <div className="smallfirst">
                      <a href="">
                        <img src={postimge}></img>
                      </a>
                    </div>
                    <div className="ml-3 smllfstpara">
                      <h5>Beautiful nature</h5>
                      <p>
                        <a href="">August 7, 2017</a>
                      </p>
                    </div>
                  </div>

                  <div className="d-flex mt-2">
                    <div className="smallfirst">
                      <a href="">
                        <img src={blogpostthrd}></img>
                      </a>
                    </div>
                    <div className="ml-3 smllfstpara">
                      <h5>City experience</h5>
                      <p>
                        <a href="">August 7, 2017</a>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-8 ">
              <div className="d-flex rightbox">
                <div className="smallclder">
                  <div className="p-2 calender-img">
                    <p>08</p>
                    <p className="smtcldr">AUGUST</p>
                  </div>
                </div>
                <div className="pl-4 island">
                  <h1>Island</h1>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Cras sollicitudin, tellus vitae condimentum egestas, libero
                    dolor auctor tellus, eu consectetur neque elit quis nunc.
                    Cras elementum pretium est. Nullam ac justo efficitur,
                    tristique ligula a, pellentesque ipsum. Quisque augue ipsum,
                    vehicula et tellus nec, maximus viverra metus. Lorem ipsum
                    dolor sit amet, consectetur adipiscing elit. Cras
                    sollicitudin, tellus vitae condimentum egestas, libero dolor
                    auctor tellus, eu consectetur neque elit quis nunc. Cras
                    elementum pretium est. Nullam ac justo efficitur, tristique
                  </p>

                  <div className="smallicon ">
                    <ul>
                      <li>
                        <i class="fa fa-heart-o" aria-hidden="true"></i> 13
                      </li>
                      <li>
                        <i class="fa fa-comments" aria-hidden="true"></i> 3
                      </li>
                      <li>
                        <i class="fa fa-tag" aria-hidden="true"></i> Holidays
                      </li>
                      <div className="socialface">
                        <li>
                          <i class="fa fa-facebook" aria-hidden="true"></i>
                        </li>
                        <li className="">
                          <i class="fa fa-twitter" aria-hidden="true"></i>
                        </li>
                      </div>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="firstvideo">
                <img src={postimge}></img>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="thirdsec mt-5">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <div className="tagspara">
                <h2>Tags</h2>
                <div className="tagslink">
                  <a href="" className="p-1">
                    Adventure,
                  </a>
                  <a href="" className="p-1">
                    Exotic,
                  </a>
                  <a href="" className="p-1">
                    Last Minute,
                  </a>
                  <br></br>
                  <a href="" className="p-1">
                    Tips Tricks,
                  </a>
                </div>
              </div>

              <div className="mt-5">
                <h2>Instagram Gallery</h2>
              </div>
            </div>
            <div className="col-md-8">
              <div className="d-flex rightbox">
                <div className="smallclder">
                  <div className="p-2 calender-img">
                    <p>08</p>
                    <p className="smtcldr">AUGUST</p>
                  </div>
                </div>
                <div className="pl-4 island">
                  <h1>Sea</h1>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Cras sollicitudin, tellus vitae condimentum egestas, libero
                    dolor auctor tellus, eu consectetur neque elit quis nunc.
                    Cras elementum pretium est. Nullam ac justo efficitur,
                    tristique ligula a, pellentesque ipsum. Quisque augue ipsum,
                    vehicula et tellus nec, maximus viverra metus. Lorem ipsum
                    dolor sit amet, consectetur adipiscing elit. Cras
                    sollicitudin, tellus vitae condimentum egestas, libero dolor
                    auctor tellus, eu consectetur neque elit quis nunc. Cras
                    elementum pretium est. Nullam ac justo efficitur, tristique
                  </p>

                  <div className="smallicon ">
                    <ul>
                      <li>
                        <i class="fa fa-heart-o" aria-hidden="true"></i> 13
                      </li>
                      <li>
                        <i class="fa fa-comments" aria-hidden="true"></i> 3
                      </li>
                      <li>
                        <i class="fa fa-tag" aria-hidden="true"></i> Holidays
                      </li>
                      <div className="socialface">
                        <li>
                          <i class="fa fa-facebook" aria-hidden="true"></i>
                        </li>
                        <li className="">
                          <i class="fa fa-twitter" aria-hidden="true"></i>
                        </li>
                      </div>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="fourthsec mt-5">
        <div className="container">
          <div className="row">
            <div className="col-md-4"></div>
            <div className="col-md-8">
              <div className="msgpara">
                <div className="post-mark">
                  <i class="fa-solid fa-quote-right"></i>
                </div>
                <div className="mesg">
                  <div>
                    <h2>
                      <a href="">
                        <i>
                          The healthy life is the best life, choose your own way
                          to do it
                        </i>
                      </a>
                    </h2>
                    <p>Jason Andrews</p>
                  </div>
                  <div className="d-flex">
                    <div className="calnder mr-3">
                      <a href="">
                        <i class="fa fa-calendar-o" aria-hidden="true"></i>
                        <span className="mr-2">August 8, 2017</span>
                      </a>
                    </div>
                    <div className="commnts mr-3">
                      <a href="">
                        <i class="fa fa-comments" aria-hidden="true"></i> 3
                      </a>
                    </div>

                    <div className="commnts">
                      <a href="">
                        <i class="fa fa-tag" aria-hidden="true"></i> Holidays
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-4"></div>
            <div className="col-md-8 ">
              <div className="mkdf-post-heading">
                <a href="">
                  <img src={imgpart}></img>
                </a>
              </div>
            </div>
          </div>

          <div className="row mt-5">
            <div className="col-md-4"></div>
            <div className="col-md-8">
              <div className="d-flex  fouhpart">
                <div className="smallclder">
                  <div className="p-2 calender-img">
                    <p>08</p>
                    <p>AUGUST</p>
                  </div>
                </div>
                <div className="pl-4 island">
                  <h1>City break</h1>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Cras sollicitudin, tellus vitae condimentum egestas, libero
                    dolor auctor tellus, eu consectetur neque elit quis nunc.
                    Cras elementum pretium est. Nullam ac justo efficitur,
                    tristique ligula a, pellentesque ipsum. Quisque augue ipsum,
                    vehicula et tellus nec, maximus viverra metus. Lorem ipsum
                    dolor sit amet, consectetur adipiscing elit. Cras
                    sollicitudin, tellus vitae condimentum egestas, libero dolor
                    auctor tellus, eu consectetur neque elit quis nunc. Cras
                    elementum pretium est. Nullam ac justo efficitur, tristique
                  </p>
                  <div className="smallicon ">
                    <ul>
                      <li>
                        <i class="fa fa-heart-o" aria-hidden="true"></i> 13
                      </li>
                      <li>
                        <i class="fa fa-comments" aria-hidden="true"></i> 3
                      </li>
                      <li>
                        <i class="fa fa-tag" aria-hidden="true"></i> Holidays
                      </li>
                      <div className="socialface">
                        <li>
                          <i class="fa fa-facebook" aria-hidden="true"></i>
                        </li>
                        <li className="">
                          <i class="fa fa-twitter" aria-hidden="true"></i>
                        </li>
                      </div>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="row">
            <div className="col-md-4"></div>
            <div className="col-md-8">
              <div className="msgpara">
                <div className="post-mark mark">
                  <i class="fa fa-link" aria-hidden="true"></i>
                </div>
                <div className="mesg">
                  <div>
                    <h2>
                      <a href="">
                        <i>We’ll have you feeling like a million bucks.</i>
                      </a>
                    </h2>
                    <p>Jason Andrews</p>
                  </div>
                  <div className="d-flex">
                    <div className="calnder mr-3">
                      <a href="">
                        <i class="fa fa-calendar-o" aria-hidden="true"></i>
                        <span className="mr-2">August 8, 2017</span>
                      </a>
                    </div>
                    <div className="commnts mr-3">
                      <a href="">
                        <i class="fa fa-comments" aria-hidden="true"></i> 3
                      </a>
                    </div>

                    <div className="commnts">
                      <a href="">
                        <i class="fa fa-tag" aria-hidden="true"></i> Holidays
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-4"></div>
            <div className="col-md-8">
              <div className="cocotree">
                <a href="">
                  <img src={coconutimg}></img>
                </a>
              </div>
            </div>
          </div>

          <div className="row jungle">
            <div className="col-md-4"></div>
            <div className="col-md-8">
              <div className="d-flex  fouhpart">
                <div className="smallclder">
                  <div className="p-2 calender-img">
                    <p>08</p>
                    <p>AUGUST</p>
                  </div>
                </div>
                <div className="pl-4 island">
                  <h1>Jungle</h1>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    Cras sollicitudin, tellus vitae condimentum egestas, libero
                    dolor auctor tellus, eu consectetur neque elit quis nunc.
                    Cras elementum pretium est. Nullam ac justo efficitur,
                    tristique ligula a, pellentesque ipsum. Quisque augue ipsum,
                    vehicula et tellus nec, maximus viverra metus. Lorem ipsum
                    dolor sit amet, consectetur adipiscing elit. Cras
                    sollicitudin, tellus vitae condimentum egestas, libero dolor
                    auctor tellus, eu consectetur neque elit quis nunc. Cras
                    elementum pretium est. Nullam ac justo efficitur, tristique
                  </p>
                  <div className="smallicon ">
                    <ul>
                      <li>
                        <i class="fa fa-heart-o" aria-hidden="true"></i> 13
                      </li>
                      <li>
                        <i class="fa fa-comments" aria-hidden="true"></i> 3
                      </li>
                      <li>
                        <i class="fa fa-tag" aria-hidden="true"></i> Holidays
                      </li>
                      <div className="socialface">
                        <li>
                          <i class="fa fa-facebook" aria-hidden="true"></i>
                        </li>
                        <li className="">
                          <i class="fa fa-twitter" aria-hidden="true"></i>
                        </li>
                      </div>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="lastsec">
          <div className="container bestpart ">
            <div className="row">
              <div className="col-md-3">
                <div className="footimg">
                  <a href="">
                    <img src={logofooter}></img>
                  </a>
                </div>
                <div className="footpara">
                  <p className="text-white">
                    Lorem ipsum dolor sit amet, consectetur adipi. Suspend isse
                    ultrices hendrerit nunc vitae vel a sodales. Ac lectus vel
                    risus suscipit venenatis.
                  </p>
                </div>
                <div className="footlink mt-4">
                  <a href="" className="text-white">
                    Strömgatan 18, Stockholm,
                  </a>
                  <br></br>
                  <a href="" className="text-white">
                    Sweden(+46) 322.170.71,
                  </a>
                  <br></br>
                  <a href="" className="text-white">
                    roam@qodeinteractive.com,
                  </a>
                </div>
              </div>
              <div className="col-md-3">
                <div className="footimg">
                  <h2 className="text-white pl-5">Links</h2>
                </div>

                <div className="footlist">
                  <ul>
                    <li>
                      <a href="">Creative styles of home</a>
                    </li>
                    <li className="pt-3">
                      <a href="">Custom image title and creative</a>
                    </li>
                    <li className="pt-3">
                      <a href="">Custom font style and contact</a>
                    </li>
                    <li className="pt-3">
                      <a href="">Smooth parallax all around</a>
                    </li>
                    <li className="pt-3">
                      <a href="">Crafted beautiful elements</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="col-md-3">
                <div className="footimg">
                  <h2 className="text-white">Twitter Feed</h2>
                </div>
                <div className="d-flex socialpara">
                  <div className="socialicon">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </div>
                  <div className="socialparagraph pl-3">
                    <p>
                      Have you ever wondered what file and folder permissions
                      stand for? We invite you to read the article in the link
                      be…
                      <a href="">https://t.co/SE5mYZJMdw</a>
                    </p>

                    <div className="mt-2">
                      <a href="">15 hours ago</a>
                    </div>
                  </div>
                </div>
                <div className="d-flex mt-4">
                  <div className="socialicon">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                  </div>
                  <div className="socialparagraph pl-3">
                    <p>
                      Have you ever wondered what file and folder permissions
                      stand for? We invite you to read the article in the link
                      be…
                      <a href="">https://t.co/SE5mYZJMdw</a>
                    </p>

                    <div className="mt-2">
                      <a href="">15 hours ago</a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="footimg">
                  <h2 className="text-white">Instagram Gallery</h2>
                </div>
                <div className="footerImageContainer">
                  <div className="footerImage">
                    <img src={galleryimg} />
                    <div className="footerImageShadow"></div>
                  </div>
                  <div className="footerImage">
                    <img src={galleryimgtwo} />
                    <div className="footerImageShadow"></div>
                  </div>
                  <div className="footerImage">
                    <img src={galleryimgthr} />
                    <div className="footerImageShadow"></div>
                  </div>
                  <div className="footerImage">
                    <img src={galleryimgfrth} />
                    <div className="footerImageShadow"></div>
                  </div>
                  <div className="footerImage">
                    <img src={galleryimgfift} />
                    <div className="footerImageShadow"></div>
                  </div>
                  <div className="footerImage">
                    <img src={galleryimgsix} />
                    <div className="footerImageShadow"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="footblock">
        <div className="container">
          <div className="row">
            <div className="col-md-6 mx-auto">
              <div className="bottomhlder">
                <p className="text-center">
                  <a href="">© 2017 Qode Interactive, All Rights Reserved</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default Blogfile;
