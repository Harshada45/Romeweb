import React, { useState } from "react";
import "../components/Blogfile.css";

function Scroll() {
  const [visible, setVisible] = useState(false);

  const toggleVisible = () => {
    const scrolled = document.documentElement.scrollTop;
    if (scrolled > 200) {
      setVisible(true);
    } else if (scrolled <= 300) {
      setVisible(false);
    }
    console.log();
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  window.addEventListener("scroll", toggleVisible);
  return (
    <>
      {visible ? (
        <div className="scrolltotop" onClick={scrollToTop}>
          <i class="fa fa-angle-up" aria-hidden="true"></i>
        </div>
      ) : (
        ""
      )}
    </>
  );
}

export default Scroll;
