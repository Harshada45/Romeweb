import React from "react";
import "../components/navbar.css";
import roamimg from "./images/roam_orange.png";
function Navbar() {
  return (
    <>
      <div className="conatiner">
        <nav class="navbar navbar-expand-md  navback navlogo fixed-top">
          <a class="navbar-brand" href="#">
            <img src={roamimg}></img>
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#collapsibleNavbar"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item dropdown">
                <a
                  class="nav-link "
                  href="#"
                  id="navbarDropdown"
                  data-toggle="dropdown"
                >
                  Home
                </a>

                <div class="dropdown-menu content">
                  <div className="topArrow"></div>
                  <div>
                    <a class="dropdown-item" href="#">
                      <span>Main Home</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span> Mountaineering Home</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Surfing Showcase</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Tours Showcase</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Travel Home</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Rafting Showcase</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Camping Home</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Holiday Home</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Adventure Home</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Destination Showcase</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Vacation Home</span>
                    </a>
                    <a class="dropdown-item" href="#">
                      <span>Landing</span>
                    </a>
                  </div>
                </div>
              </li>
              <li class="nav-item dropdown">
                <a
                  class="nav-link "
                  href="#"
                  id="navbarDropdown"
                  data-toggle="dropdown"
                >
                  Destination
                </a>
                <div class="dropdown-menu">
                  <div className="topArrow"></div>
                  <a class="dropdown-item" href="#">
                    <span>Destinations List</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span> Destination Item</span>
                  </a>
                </div>
              </li>

              <li class="nav-item dropdown">
                <a
                  class="nav-link "
                  href="#"
                  id="navbarDropdown"
                  data-toggle="dropdown"
                >
                  Tours
                </a>
                <div class="dropdown-menu">
                  <div className="topArrow"></div>
                  <a class="dropdown-item" href="#">
                    <span>Standard List</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>Revealing Info List</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>Gallery Simple List</span>
                  </a>

                  <a class="dropdown-item" href="#">
                    <span>Tour Item</span>
                  </a>
                </div>
              </li>

              <li class="nav-item dropdown">
                <a
                  class="nav-link "
                  href="#"
                  id="navbarDropdown"
                  data-toggle="dropdown"
                >
                  Pages
                </a>
                <div class="dropdown-menu">
                  <div className="topArrow"></div>
                  <a class="dropdown-item" href="#">
                    <span>About Us</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>What We Offer</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>Our Team</span>
                  </a>

                  <a class="dropdown-item" href="#">
                    <span>Contact Us</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>Coming Soon</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>404 Error Page</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>shop</span>
                  </a>
                </div>
              </li>

              <li class="nav-item dropdown">
                <a
                  class="nav-link "
                  href="#"
                  id="navbarDropdown"
                  data-toggle="dropdown"
                >
                  Blog
                </a>
                <div class="dropdown-menu">
                  <div className="topArrow"></div>
                  <a class="dropdown-item" href="#">
                    <span>List No Sidebar</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>List Left Sidebar</span>
                  </a>
                  <a class="dropdown-item" href="#">
                    <span>List Right Sidebar</span>
                  </a>

                  <a class="dropdown-item" href="#">
                    <span>Post Types</span>
                  </a>
                </div>
              </li>

              <li class="nav-item dropdown">
                <a
                  class="nav-link "
                  href="#"
                  id="navbarDropdown"
                  data-toggle="dropdown"
                >
                  Elements
                </a>
                <div class="dropdown-content">
                  <div className="topArrowlast"></div>
                  <div class="row">
                    <div class="column">
                      <div className="rightborder">
                        <span>Featured</span>
                        <a href="#">Tours Carousel</a>
                        <a href="#">Tours List</a>
                        <a href="#">Tours Filters</a>
                        <a href="">Destinations Masonry</a>
                        <a href="">Destinations Grid</a>
                        <a href="">Advanced Link Section</a>
                        <a href="">Banner</a>
                        <a href="">Team List</a>
                      </div>
                    </div>
                    <div class="column">
                      <div className="rightborder">
                        <span>Classic</span>
                        <a href="#">Accordions</a>
                        <a href="#">Blockquote</a>
                        <a href="#">Buttons</a>
                        <a href="">Call To Action</a>
                        <a href="">Contact Form</a>
                        <a href="">Google Maps</a>
                        <a href="">Image Gallery</a>
                        <a href="">Separators</a>
                      </div>
                    </div>
                    <div class="column">
                      <div className="rightborder">
                        <span>Infographic</span>
                        <a href="#">Countdown</a>
                        <a href="#">Counters</a>
                        <a href="#">Horizontal Progress Bars</a>
                        <a href="">Pie Charts</a>
                        <a href="">Blog List Shortcode</a>
                        <a href="">Testimonials</a>
                        <a href="">Client Carousel</a>
                        <a href="">Video Button</a>
                      </div>
                    </div>
                    <div class="column typogrph">
                      <span>Typography</span>
                      <a href="#">Headings</a>
                      <a href="#">Columns</a>
                      <a href="#">Custom Font</a>
                      <a href="">Dropcaps</a>
                      <a href="">Highlights</a>
                      <a href="">Icon With Text</a>
                      <a href="">Lists</a>
                      <a href="">Title & Subtitle</a>
                    </div>
                  </div>
                </div>
              </li>

              <li class="nav-item">
                <a class="dropdown-item" href="#">
                  <span>
                    <i class="fa fa-search" aria-hidden="true"></i>
                  </span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </>
  );
}

export default Navbar;
