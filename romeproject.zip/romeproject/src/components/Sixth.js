import React, { useEffect, useState } from "react";
import axois from "axios";

function Sixth() {
  const [data, setData] = useState([]);
  const [user, setUser] = useState({
    id: -1,
    name: "",
    email: "",
    address: "",
    age: "",
  });
  const [btnstate, setbtnstate] = useState(false);

  const handeldata = (e) => {
    // console.log(user);
    let name = e.target.name;
    let value = e.target.value;
    setUser({ ...user, [name]: value });
  };

  //delete api
  const postDelete = (sid) => {
    // alert(id);
    console.log(sid);
    axois
      .post(
        `https://nikhil525.000webhostapp.com/api/harshada/deleteUser.php`,
        JSON.stringify({ id: sid })
      )
      .then((res) => {
        console.log(res);
        livedata();
      });
  };

  //update api
  const updateData = (sitem) => {
    console.log(sitem);
    // axois
    //   .post(
    //     `https://nikhil525.000webhostapp.com/api/harshada/updateUser.php`,
    //     JSON.stringify({ id: pid })
    //   )
    //   .then((res) => {
    //     console.log(res);
    //     livedata();
    //   });
    setbtnstate(true);
    // setUser(sitem);
    setUser({
      id: parseInt(sitem.id),
      name: sitem.name,
      email: sitem.email,
      address: sitem.address,
      age: sitem.age,
    });
  };

  const updateRow = () => {
    axois
      .post(
        `https://nikhil525.000webhostapp.com/api/harshada/updateUser.php`,
        JSON.stringify({ user })
      )
      .then((res) => {
        console.log(res);
        livedata();
      });
    console.log(typeof user.id);
  };
  const submitdata = () => {
    axois
      .post(
        `https://nikhil525.000webhostapp.com/api/harshada/createUser.php`,
        JSON.stringify(user)
      )
      .then((res) => {
        console.log(res);
        console.log(res.data.user);
        console.log(user);
        livedata();
      });
  };
  useEffect(() => {
    livedata();
  }, []);

  //post api
  const livedata = () => {
    axois
      .get(`https://nikhil525.000webhostapp.com/api/harshada/listUser.php`)
      .then((res) => {
        console.log(res);
        setData(res.data.user);
      });
  };

  return (
    <div>
      <h1>Get API Call</h1>
      <form>
        <label>Name</label>
        <input
          type="text"
          name="name"
          value={user.name}
          onChange={handeldata}
        />
        <br></br>
        <label>Email</label>
        <input
          type="text"
          name="email"
          value={user.email}
          onChange={handeldata}
        />
        <br></br>
        <label>Address</label>
        <input
          type="text"
          name="address"
          value={user.address}
          onChange={handeldata}
        />
        <br></br>
        <label>Age</label>
        <input type="text" name="age" value={user.age} onChange={handeldata} />
        <br></br>
        {btnstate ? (
          <>
            <button
              type="button"
              className="btn btn-success"
              onClick={updateRow}
            >
              Update
            </button>
            &nbsp;
            <button
              type="button"
              className="btn btn-danger"
              onClick={() => {
                setbtnstate(false);
              }}
            >
              cancel
            </button>
          </>
        ) : (
          <button type="button" onClick={submitdata} className="btn btn-info">
            Submit
          </button>
        )}
      </form>

      <table border="1">
        <tr className="text-center">
          <th>Id</th>
          <th>Name</th>
          <th>Email</th>
          <th>Address</th>
          <th>Age</th>
          <th>Action</th>
        </tr>
        {data.map((item) => (
          <tr>
            <td>{item.id}</td>
            <td>{item.name}</td>
            <td>{item.email}</td>
            <td>{item.address}</td>
            <td>{item.age}</td>
            <td>
              <button
                onClick={() => postDelete(item.id)}
                type="button"
                className="btn btn-danger"
              >
                Delete
              </button>
              <button
                onClick={() => updateData(item)}
                type="button"
                className="btn btn-success"
              >
                Update
              </button>
            </td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Sixth;
