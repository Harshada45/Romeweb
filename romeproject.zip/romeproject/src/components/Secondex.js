import React, { useEffect, useState } from "react";

function Secondex() {
  const [data, setData] = useState([]);
  const [user, setUser] = useState({
    id: "",
    name: "",
    age: "",
    gender: "",
    address: "",
    state: "",
    state_id: "",
    district: "",
    district_id: "",
  });

  const heandelData = (e) => {
    console.log(user);
    let name = e.target.name;
    let value = e.target.value;
    setUser({ ...user, [name]: value });
  };

  useEffect(() => {
    fetch("https://nikhil525.000webhostapp.com/api/listuser.php").then(
      (result) => {
        result.json().then((resp) => {
          setData(resp.user);
          console.log(data);
        });
      }
    );
  }, []);

  const submitButton = () => {
    console.log(setUser);
    fetch("https://nikhil525.000webhostapp.com/api/createUser.php", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(user),
    }).then((result) => {
      result.json().then((resp) => {
        console.log("resp", resp);
      });
    });
  };

  return (
    <div>
      <h1>Get API Call</h1>

      <form>
        <labe>Id:</labe>
        <input
          type="text"
          value={user.id}
          name="id"
          onChange={heandelData}
        ></input>
        <br></br>
        <label>Name:</label>
        <input
          type="text"
          value={user.name}
          name="name"
          onChange={heandelData}
        ></input>
        <br></br>
        <label>Age:</label>
        <input
          type="text"
          value={user.age}
          name="age"
          onChange={heandelData}
        ></input>
        <br></br>
        <label>Gender:</label>
        <input
          type="text"
          value={user.gender}
          name="gender"
          onChange={heandelData}
        ></input>
        <br></br>

        <label>Address</label>
        <input
          type="text"
          value={user.address}
          name="address"
          onChange={heandelData}
        ></input>
        <br></br>

        <label>State</label>
        <input
          type="text"
          value={user.state}
          name="state"
          onChange={heandelData}
        ></input>
        <br></br>

        <label>State Id</label>
        <input
          type="text"
          value={user.state_id}
          name="state_id"
          onChange={heandelData}
        ></input>
        <br></br>

        <label>District</label>
        <input
          type="text"
          value={user.district}
          name="district"
          onChange={heandelData}
        ></input>
        <br></br>

        <label>District Id</label>
        <input
          type="text"
          value={user.district_id}
          name="district_id"
          onChange={heandelData}
        ></input>
        <br></br>
        <button type="button" onClick={submitButton}>
          Submit
        </button>
      </form>

      <table border="1">
        <tr className="text-center">
          <th>Id</th>
          <th>Name</th>
          <th>Age</th>
          <th>Gender</th>
          <th>Address</th>
          <th>State</th>
          <th>State Id</th>
          <th>District</th>
          <th>District Id</th>
        </tr>
        {data.map((item) => (
          <tr className="text-center">
            <td>{item.id}</td>
            <td>{item.name}</td>
            <td>{item.age}</td>
            <td>{item.gender}</td>
            <td>{item.address}</td>
            <td>{item.state}</td>
            <td>{item.state_id}</td>
            <td>{item.district}</td>
            <td>{item.district_id}</td>
          </tr>
        ))}
        {console.log(data)}
      </table>
    </div>
  );
}

export default Secondex;
