import React, { useEffect, useState } from "react";

function Thirdex() {
  const [user, setuser] = useState([]);

  useEffect(() => {
    console.log(user);
  });

  const heandelData = (e) => {
    console.log("change");
    let name = e.target.name;
    let value = e.target.value;
    setuser({ ...user, [name]: value });
  };

  useEffect = () => {
    fetch("https://nikhil525.000webhostapp.com/api/listuser.php").then(
      (result) => {
        result.json().then((resp) => {
          console.log("resp", resp);
          setuser(resp);
        });
      }
    );
    // console.log(user);
  };
  return (
    <div>
      <h1>GET API EXAMPLE</h1>
      <table border="1">
        <tr>
          <th>
            <td>Id</td>
            <td>Name</td>
            <td>Age</td>
            <td>Gender</td>
            <td>Address</td>
            <td>State</td>
            <td>State Id</td>
            <td>District</td>
            <td>District Id</td>
          </th>
        </tr>
        {user.map((item) => (
          <tr>
            <td>{item.id}</td>
            <td>{item.name}</td>
            <td>{item.age}</td>
            <td>{item.gender}</td>
            <td>{item.address}</td>
            <td>{item.state}</td>
            <td>{item.state_id}</td>
            <td>{item.district}</td>
            <td>{item.district_id}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Thirdex;
