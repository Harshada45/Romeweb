import logo from "./logo.svg";

import Blogfile from "./components/Blogfile";
import Navbar from "./components/Navbar";
import Scroll from "./components/Scroll";
import Firstex from "./components/Firstex";
import Secondex from "./components/Secondex";
import Thirdex from "./components/Thirdex";
import Sixth from "./components/Sixth";

function App() {
  return (
    <div className="">
      <Navbar />
      <Blogfile />
      <Scroll />
      {/* <Firstex /> 
       <Secondex />  */}
      {/* <Thirdex /> */}
      {/* {/* <Sixth /> */}
    </div>
  );
}

export default App;
